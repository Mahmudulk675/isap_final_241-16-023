package com.example.EventEase.controller;

import com.example.EventEase.entity.User;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.Matchers.containsString;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
class EventControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Test
    void testHomePage() throws Exception {
        mockMvc.perform(get("/"))
                .andExpect(status().isOk())
                .andExpect(view().name("index"))
                .andExpect(content().string(containsString("Welcome to EventEase")));
    }

    @Test
    void testEventsPage() throws Exception {
        mockMvc.perform(get("/events"))
                .andExpect(status().isOk())
                .andExpect(view().name("events/list"))
                .andExpect(content().string(containsString("Upcoming Events")));
    }

    @Test
    void testLoginPage() throws Exception {
        mockMvc.perform(get("/login"))
                .andExpect(status().isOk())
                .andExpect(view().name("auth/login"))
                .andExpect(content().string(containsString("Account Login")));
    }

    @Test
    void testRegisterPage() throws Exception {
        mockMvc.perform(get("/register"))
                .andExpect(status().isOk())
                .andExpect(view().name("auth/register"))
                .andExpect(content().string(containsString("Create Account")));
    }

    @Test
    void testAdminProtectedPageWithoutLoginRedirects() throws Exception {
        mockMvc.perform(get("/events/admin"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/login?redirect=/events/admin"));
    }

    @Test
    void testAdminProtectedPageWithAdminSessionSucceeds() throws Exception {
        MockHttpSession adminSession = new MockHttpSession();
        User adminUser = new User("Admin", "admin@eventease.com", "admin123", "01700000000", "ADMIN");
        adminSession.setAttribute("currentUser", adminUser);

        mockMvc.perform(get("/events/admin").session(adminSession))
                .andExpect(status().isOk())
                .andExpect(view().name("events/admin"))
                .andExpect(content().string(containsString("Manage Events")));
    }

    @Test
    void testSuccessfulLoginFlow() throws Exception {
        mockMvc.perform(post("/login")
                        .param("email", "admin@eventease.com")
                        .param("password", "admin123"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/events/admin"));
    }

    @Test
    void testFailedLoginFlow() throws Exception {
        mockMvc.perform(post("/login")
                        .param("email", "admin@eventease.com")
                        .param("password", "wrongpassword"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/login"))
                .andExpect(flash().attributeExists("errorMessage"));
    }
}
