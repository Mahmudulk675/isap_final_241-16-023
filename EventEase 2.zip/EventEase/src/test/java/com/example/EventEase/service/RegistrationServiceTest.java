package com.example.EventEase.service;

import com.example.EventEase.entity.Category;
import com.example.EventEase.entity.Event;
import com.example.EventEase.entity.Registration;
import com.example.EventEase.entity.User;
import com.example.EventEase.entity.Venue;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@Transactional
class RegistrationServiceTest {

    @Autowired
    private RegistrationService registrationService;

    @Autowired
    private UserService userService;

    @Autowired
    private EventService eventService;

    @Autowired
    private CategoryService categoryService;

    @Autowired
    private VenueService venueService;

    private User testUser1;
    private User testUser2;
    private Event limitedEvent;

    @BeforeEach
    void setUp() {
        Category category = categoryService.saveCategory(new Category("Tech"));
        Venue venue = venueService.saveVenue(new Venue("Room 101", "Campus"));

        testUser1 = userService.saveUser(new User("Test User 1", "test1@example.com", "pass123", "1234567890", "USER"));
        testUser2 = userService.saveUser(new User("Test User 2", "test2@example.com", "pass123", "0987654321", "USER"));

        // Create an event with capacity of 1
        limitedEvent = eventService.saveEvent(new Event(
                "Limited Workshop",
                "Only 1 seat available",
                LocalDate.now().plusDays(5),
                "10:00 AM",
                1,
                0.0,
                category,
                venue
        ));
    }

    @Test
    void testSuccessfulRegistration() {
        Registration reg = registrationService.registerUserForEvent(testUser1.getId(), limitedEvent.getId());
        assertNotNull(reg.getId());
        assertEquals(testUser1.getId(), reg.getUser().getId());
        assertEquals(limitedEvent.getId(), reg.getEvent().getId());

        int remainingSeats = eventService.getAvailableSeats(limitedEvent.getId());
        assertEquals(0, remainingSeats);
    }

    @Test
    void testPreventDuplicateRegistration() {
        registrationService.registerUserForEvent(testUser1.getId(), limitedEvent.getId());

        // Attempting to register the same user for the same event must fail
        IllegalArgumentException exception = assertThrows(
                IllegalArgumentException.class,
                () -> registrationService.registerUserForEvent(testUser1.getId(), limitedEvent.getId())
        );

        assertTrue(exception.getMessage().contains("already registered"));
    }

    @Test
    void testPreventRegistrationWhenEventIsFull() {
        // First user takes the only seat (capacity = 1)
        registrationService.registerUserForEvent(testUser1.getId(), limitedEvent.getId());

        // Second user attempts to register
        IllegalStateException exception = assertThrows(
                IllegalStateException.class,
                () -> registrationService.registerUserForEvent(testUser2.getId(), limitedEvent.getId())
        );

        assertTrue(exception.getMessage().contains("full"));
    }

    @Test
    void testUserAuthentication() {
        User authenticated = userService.authenticate("test1@example.com", "pass123");
        assertNotNull(authenticated);
        assertEquals("Test User 1", authenticated.getName());

        User wrongPass = userService.authenticate("test1@example.com", "wrongpass");
        assertNull(wrongPass);

        User nonExistent = userService.authenticate("nobody@example.com", "pass123");
        assertNull(nonExistent);
    }
}
