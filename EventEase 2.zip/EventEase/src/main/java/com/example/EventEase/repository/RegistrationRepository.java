package com.example.EventEase.repository;

import com.example.EventEase.entity.Event;
import com.example.EventEase.entity.Registration;
import com.example.EventEase.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RegistrationRepository extends JpaRepository<Registration, Long> {
    boolean existsByUserAndEvent(User user, Event event);
    long countByEvent(Event event);
    List<Registration> findByEventId(Long eventId);
    List<Registration> findByUserId(Long userId);
}
