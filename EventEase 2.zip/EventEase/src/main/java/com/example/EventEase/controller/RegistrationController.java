package com.example.EventEase.controller;

import com.example.EventEase.entity.Event;
import com.example.EventEase.entity.Registration;
import com.example.EventEase.entity.User;
import com.example.EventEase.service.EventService;
import com.example.EventEase.service.RegistrationService;
import com.example.EventEase.service.UserService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
public class RegistrationController {

    private final RegistrationService registrationService;
    private final EventService eventService;
    private final UserService userService;

    public RegistrationController(RegistrationService registrationService,
                                  EventService eventService,
                                  UserService userService) {
        this.registrationService = registrationService;
        this.eventService = eventService;
        this.userService = userService;
    }

    // 1. View all registrations (Admin view)
    @GetMapping("/registrations")
    public String listRegistrations(HttpSession session, Model model, RedirectAttributes redirectAttributes) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null) {
            redirectAttributes.addFlashAttribute("errorMessage", "Please log in to view registrations.");
            return "redirect:/login?redirect=/registrations";
        }

        // If regular user, redirect to personal registrations
        if (!currentUser.isAdmin()) {
            return "redirect:/my-registrations";
        }

        model.addAttribute("registrations", registrationService.getAllRegistrations());
        return "registrations/list";
    }

    // 2. View personal registrations (User view)
    @GetMapping("/my-registrations")
    public String listMyRegistrations(HttpSession session, Model model, RedirectAttributes redirectAttributes) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null) {
            redirectAttributes.addFlashAttribute("errorMessage", "Please log in to view your registrations.");
            return "redirect:/login?redirect=/my-registrations";
        }

        List<Registration> myRegistrations = registrationService.getRegistrationsByUserId(currentUser.getId());
        model.addAttribute("registrations", myRegistrations);
        return "registrations/my-registrations";
    }

    // 3. Show registration confirmation form for a specific event
    @GetMapping("/registrations/new/{eventId}")
    public String showRegistrationForm(@PathVariable Long eventId,
                                       HttpSession session,
                                       Model model,
                                       RedirectAttributes redirectAttributes) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null) {
            redirectAttributes.addFlashAttribute("errorMessage", "Please log in or register an account to sign up for events.");
            return "redirect:/login?redirect=/registrations/new/" + eventId;
        }

        Event event = eventService.getEventById(eventId);
        if (event == null) {
            redirectAttributes.addFlashAttribute("errorMessage", "Event not found!");
            return "redirect:/events";
        }

        int availableSeats = eventService.getAvailableSeats(eventId);
        if (availableSeats <= 0) {
            redirectAttributes.addFlashAttribute("errorMessage", "Sorry, this event is already full!");
            return "redirect:/events/" + eventId;
        }

        model.addAttribute("event", event);
        model.addAttribute("availableSeats", availableSeats);
        model.addAttribute("currentUser", currentUser);
        model.addAttribute("users", userService.getAllUsers());
        return "registrations/form";
    }

    // 4. Process registration submission
    @PostMapping("/registrations/save")
    public String saveRegistration(@RequestParam(value = "userId", required = false) Long userId,
                                   @RequestParam("eventId") Long eventId,
                                   HttpSession session,
                                   RedirectAttributes redirectAttributes) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null) {
            redirectAttributes.addFlashAttribute("errorMessage", "Please log in to register.");
            return "redirect:/login?redirect=/registrations/new/" + eventId;
        }

        // If userId is not provided, use the currently logged-in user's ID
        Long targetUserId = (userId != null && currentUser.isAdmin()) ? userId : currentUser.getId();

        try {
            registrationService.registerUserForEvent(targetUserId, eventId);
            redirectAttributes.addFlashAttribute("successMessage", "Registration successful! You are enrolled in the event.");
            return currentUser.isAdmin() ? "redirect:/registrations" : "redirect:/my-registrations";
        } catch (IllegalArgumentException | IllegalStateException e) {
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
            return "redirect:/registrations/new/" + eventId;
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "An error occurred during registration. Please try again.");
            return "redirect:/registrations/new/" + eventId;
        }
    }

    // 5. Cancel / Delete registration
    @GetMapping("/registrations/delete/{id}")
    public String deleteRegistration(@PathVariable Long id,
                                     HttpSession session,
                                     RedirectAttributes redirectAttributes) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null) {
            redirectAttributes.addFlashAttribute("errorMessage", "Please log in.");
            return "redirect:/login";
        }

        try {
            registrationService.deleteRegistration(id);
            redirectAttributes.addFlashAttribute("successMessage", "Registration cancelled successfully!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Could not cancel registration.");
        }

        return currentUser.isAdmin() ? "redirect:/registrations" : "redirect:/my-registrations";
    }
}
