package com.example.EventEase;

import com.example.EventEase.entity.Category;
import com.example.EventEase.entity.Event;
import com.example.EventEase.entity.Registration;
import com.example.EventEase.entity.User;
import com.example.EventEase.entity.Venue;
import com.example.EventEase.repository.CategoryRepository;
import com.example.EventEase.repository.EventRepository;
import com.example.EventEase.repository.RegistrationRepository;
import com.example.EventEase.repository.UserRepository;
import com.example.EventEase.repository.VenueRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Component
public class DataLoader implements CommandLineRunner {

    private final UserRepository userRepository;
    private final CategoryRepository categoryRepository;
    private final VenueRepository venueRepository;
    private final EventRepository eventRepository;
    private final RegistrationRepository registrationRepository;

    public DataLoader(UserRepository userRepository,
                      CategoryRepository categoryRepository,
                      VenueRepository venueRepository,
                      EventRepository eventRepository,
                      RegistrationRepository registrationRepository) {
        this.userRepository = userRepository;
        this.categoryRepository = categoryRepository;
        this.venueRepository = venueRepository;
        this.eventRepository = eventRepository;
        this.registrationRepository = registrationRepository;
    }

    @Override
    public void run(String... args) throws Exception {
        if (categoryRepository.count() == 0) {

            // 1. Categories
            Category workshop = categoryRepository.save(new Category("Workshop"));
            Category seminar = categoryRepository.save(new Category("Seminar"));
            Category cultural = categoryRepository.save(new Category("Cultural"));
            Category sports = categoryRepository.save(new Category("Sports"));

            // 2. Venues
            Venue auditorium = venueRepository.save(new Venue("DIU Auditorium", "Main Campus, Building 4"));
            Venue seminarHall = venueRepository.save(new Venue("Main Seminar Hall", "Academic Building 1, 2nd Floor"));
            Venue computerLab = venueRepository.save(new Venue("Computer Lab 3", "IT Building, 4th Floor"));

            // 3. Admin and Users (with passwords and roles)
            User admin = userRepository.save(new User("System Administrator", "admin@eventease.com", "admin123", "01700000000", "ADMIN"));
            User rahim = userRepository.save(new User("Rahim Ahmed", "rahim@example.com", "user123", "01711111111", "USER"));
            User karim = userRepository.save(new User("Karim Ullah", "karim@example.com", "user123", "01822222222", "USER"));
            User nusrat = userRepository.save(new User("Nusrat Jahan", "nusrat@example.com", "user123", "01933333333", "USER"));

            // 4. Events
            Event springWorkshop = new Event(
                    "Spring Boot Workshop",
                    "A hands-on beginner-friendly workshop exploring Spring Boot, Spring Data JPA, MVC, and Thymeleaf.",
                    LocalDate.now().plusDays(10),
                    "10:00 AM",
                    30,
                    100.0,
                    workshop,
                    auditorium
            );
            eventRepository.save(springWorkshop);

            Event aiSeminar = new Event(
                    "AI & Machine Learning Seminar",
                    "Explore modern trends in Artificial Intelligence, Deep Learning, and future career paths.",
                    LocalDate.now().plusDays(15),
                    "02:00 PM",
                    50,
                    0.0,
                    seminar,
                    seminarHall
            );
            eventRepository.save(aiSeminar);

            Event culturalNight = new Event(
                    "Annual Cultural Night 2026",
                    "Join us for musical performances, dramas, traditional dance, and cultural celebrations.",
                    LocalDate.now().plusDays(20),
                    "06:30 PM",
                    100,
                    50.0,
                    cultural,
                    auditorium
            );
            eventRepository.save(culturalNight);

            Event progContest = new Event(
                    "Inter-University Programming Contest",
                    "Intense 5-hour competitive programming contest with algorithm challenges and prize awards.",
                    LocalDate.now().plusDays(25),
                    "09:00 AM",
                    2, // Small capacity of 2 for easy testing of "Event Full" condition
                    200.0,
                    workshop,
                    computerLab
            );
            eventRepository.save(progContest);

            // 5. Initial Registrations
            registrationRepository.save(new Registration(rahim, springWorkshop, LocalDateTime.now().minusDays(2)));
            registrationRepository.save(new Registration(karim, springWorkshop, LocalDateTime.now().minusDays(1)));
            registrationRepository.save(new Registration(nusrat, aiSeminar, LocalDateTime.now().minusHours(5)));

            System.out.println(">>> Sample data with Admin and User accounts loaded successfully into H2 Database!");
        }
    }
}
