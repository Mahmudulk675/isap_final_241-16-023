package com.example.EventEase.controller;

import com.example.EventEase.entity.Event;
import com.example.EventEase.entity.User;
import com.example.EventEase.service.CategoryService;
import com.example.EventEase.service.EventService;
import com.example.EventEase.service.RegistrationService;
import com.example.EventEase.service.VenueService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/events")
public class EventController {

    private final EventService eventService;
    private final CategoryService categoryService;
    private final VenueService venueService;
    private final RegistrationService registrationService;

    public EventController(EventService eventService,
                           CategoryService categoryService,
                           VenueService venueService,
                           RegistrationService registrationService) {
        this.eventService = eventService;
        this.categoryService = categoryService;
        this.venueService = venueService;
        this.registrationService = registrationService;
    }

    // Helper method to check admin privileges
    private boolean isAdmin(HttpSession session) {
        User user = (User) session.getAttribute("currentUser");
        return user != null && user.isAdmin();
    }

    // 1. User/Public Side: View all events
    @GetMapping
    public String listEvents(Model model) {
        model.addAttribute("events", eventService.getAllEvents());
        return "events/list";
    }

    // 2. User/Public Side: View single event details
    @GetMapping("/{id}")
    public String viewEventDetails(@PathVariable Long id, Model model, RedirectAttributes redirectAttributes) {
        Event event = eventService.getEventById(id);
        if (event == null) {
            redirectAttributes.addFlashAttribute("errorMessage", "Event not found!");
            return "redirect:/events";
        }
        int availableSeats = eventService.getAvailableSeats(id);
        long registeredCount = registrationService.getRegistrationCountForEvent(id);

        model.addAttribute("event", event);
        model.addAttribute("availableSeats", availableSeats);
        model.addAttribute("registeredCount", registeredCount);
        model.addAttribute("isFull", availableSeats <= 0);
        return "events/details";
    }

    // 3. Admin Side: View all events in management table
    @GetMapping("/admin")
    public String adminListEvents(HttpSession session, Model model, RedirectAttributes redirectAttributes) {
        if (!isAdmin(session)) {
            redirectAttributes.addFlashAttribute("errorMessage", "Administrator privileges required to access management portal.");
            return "redirect:/login?redirect=/events/admin";
        }
        model.addAttribute("events", eventService.getAllEvents());
        return "events/admin";
    }

    // 4. Admin Side: Add event form
    @GetMapping("/new")
    public String showCreateForm(HttpSession session, Model model, RedirectAttributes redirectAttributes) {
        if (!isAdmin(session)) {
            redirectAttributes.addFlashAttribute("errorMessage", "Administrator privileges required.");
            return "redirect:/login?redirect=/events/new";
        }
        model.addAttribute("event", new Event());
        model.addAttribute("categories", categoryService.getAllCategories());
        model.addAttribute("venues", venueService.getAllVenues());
        return "events/form";
    }

    // 5. Admin Side: Edit event form
    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable Long id, HttpSession session, Model model, RedirectAttributes redirectAttributes) {
        if (!isAdmin(session)) {
            redirectAttributes.addFlashAttribute("errorMessage", "Administrator privileges required.");
            return "redirect:/login";
        }
        Event event = eventService.getEventById(id);
        if (event == null) {
            redirectAttributes.addFlashAttribute("errorMessage", "Event not found!");
            return "redirect:/events/admin";
        }
        model.addAttribute("event", event);
        model.addAttribute("categories", categoryService.getAllCategories());
        model.addAttribute("venues", venueService.getAllVenues());
        return "events/form";
    }

    // 6. Admin Side: Save event (Create or Update)
    @PostMapping("/save")
    public String saveEvent(@Valid @ModelAttribute("event") Event event,
                            BindingResult result,
                            HttpSession session,
                            Model model,
                            RedirectAttributes redirectAttributes) {
        if (!isAdmin(session)) {
            redirectAttributes.addFlashAttribute("errorMessage", "Administrator privileges required.");
            return "redirect:/login";
        }
        if (result.hasErrors()) {
            model.addAttribute("categories", categoryService.getAllCategories());
            model.addAttribute("venues", venueService.getAllVenues());
            return "events/form";
        }

        eventService.saveEvent(event);
        redirectAttributes.addFlashAttribute("successMessage", "Event saved successfully!");
        return "redirect:/events/admin";
    }

    // 7. Admin Side: Delete event
    @GetMapping("/delete/{id}")
    public String deleteEvent(@PathVariable Long id, HttpSession session, RedirectAttributes redirectAttributes) {
        if (!isAdmin(session)) {
            redirectAttributes.addFlashAttribute("errorMessage", "Administrator privileges required.");
            return "redirect:/login";
        }
        try {
            eventService.deleteEvent(id);
            redirectAttributes.addFlashAttribute("successMessage", "Event deleted successfully!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Could not delete event. It may have active registrations.");
        }
        return "redirect:/events/admin";
    }
}
