package com.example.EventEase.controller;

import com.example.EventEase.entity.User;
import com.example.EventEase.entity.Venue;
import com.example.EventEase.service.VenueService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/venues")
public class VenueController {

    private final VenueService venueService;

    public VenueController(VenueService venueService) {
        this.venueService = venueService;
    }

    private boolean isAdmin(HttpSession session) {
        User user = (User) session.getAttribute("currentUser");
        return user != null && user.isAdmin();
    }

    @GetMapping
    public String listVenues(HttpSession session, Model model, RedirectAttributes redirectAttributes) {
        if (!isAdmin(session)) {
            redirectAttributes.addFlashAttribute("errorMessage", "Administrator privileges required.");
            return "redirect:/login?redirect=/venues";
        }
        model.addAttribute("venues", venueService.getAllVenues());
        return "venues/list";
    }

    @GetMapping("/new")
    public String showCreateForm(HttpSession session, Model model, RedirectAttributes redirectAttributes) {
        if (!isAdmin(session)) {
            redirectAttributes.addFlashAttribute("errorMessage", "Administrator privileges required.");
            return "redirect:/login?redirect=/venues/new";
        }
        model.addAttribute("venue", new Venue());
        return "venues/form";
    }

    @PostMapping("/save")
    public String saveVenue(@Valid @ModelAttribute("venue") Venue venue,
                            BindingResult result,
                            HttpSession session,
                            RedirectAttributes redirectAttributes) {
        if (!isAdmin(session)) {
            redirectAttributes.addFlashAttribute("errorMessage", "Administrator privileges required.");
            return "redirect:/login";
        }
        if (result.hasErrors()) {
            return "venues/form";
        }
        venueService.saveVenue(venue);
        redirectAttributes.addFlashAttribute("successMessage", "Venue saved successfully!");
        return "redirect:/venues";
    }

    @GetMapping("/delete/{id}")
    public String deleteVenue(@PathVariable Long id, HttpSession session, RedirectAttributes redirectAttributes) {
        if (!isAdmin(session)) {
            redirectAttributes.addFlashAttribute("errorMessage", "Administrator privileges required.");
            return "redirect:/login";
        }
        try {
            venueService.deleteVenue(id);
            redirectAttributes.addFlashAttribute("successMessage", "Venue deleted successfully!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Could not delete venue. Events may be scheduled here.");
        }
        return "redirect:/venues";
    }
}
