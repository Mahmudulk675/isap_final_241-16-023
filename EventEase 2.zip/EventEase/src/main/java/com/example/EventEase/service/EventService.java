package com.example.EventEase.service;

import com.example.EventEase.entity.Event;
import com.example.EventEase.repository.EventRepository;
import com.example.EventEase.repository.RegistrationRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EventService {

    private final EventRepository eventRepository;
    private final RegistrationRepository registrationRepository;

    public EventService(EventRepository eventRepository, RegistrationRepository registrationRepository) {
        this.eventRepository = eventRepository;
        this.registrationRepository = registrationRepository;
    }

    public List<Event> getAllEvents() {
        return eventRepository.findAll();
    }

    public Event getEventById(Long id) {
        return eventRepository.findById(id).orElse(null);
    }

    public Event saveEvent(Event event) {
        return eventRepository.save(event);
    }

    public void deleteEvent(Long id) {
        eventRepository.deleteById(id);
    }

    public int getAvailableSeats(Long eventId) {
        Event event = getEventById(eventId);
        if (event == null) {
            return 0;
        }
        long registeredCount = registrationRepository.countByEvent(event);
        int available = event.getCapacity() - (int) registeredCount;
        return Math.max(0, available);
    }

    public List<Event> getEventsByCategory(Long categoryId) {
        return eventRepository.findByCategoryId(categoryId);
    }
}
