package com.example.EventEase.controller;

import com.example.EventEase.service.CategoryService;
import com.example.EventEase.service.EventService;
import com.example.EventEase.service.RegistrationService;
import com.example.EventEase.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

    private final EventService eventService;
    private final UserService userService;
    private final RegistrationService registrationService;
    private final CategoryService categoryService;

    public HomeController(EventService eventService,
                          UserService userService,
                          RegistrationService registrationService,
                          CategoryService categoryService) {
        this.eventService = eventService;
        this.userService = userService;
        this.registrationService = registrationService;
        this.categoryService = categoryService;
    }

    @GetMapping("/")
    public String home(Model model) {
        model.addAttribute("events", eventService.getAllEvents());
        model.addAttribute("totalEvents", eventService.getAllEvents().size());
        model.addAttribute("totalUsers", userService.getAllUsers().size());
        model.addAttribute("totalRegistrations", registrationService.getAllRegistrations().size());
        model.addAttribute("totalCategories", categoryService.getAllCategories().size());
        return "index";
    }
}
