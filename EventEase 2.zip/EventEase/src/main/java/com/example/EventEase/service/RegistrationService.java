package com.example.EventEase.service;

import com.example.EventEase.entity.Event;
import com.example.EventEase.entity.Registration;
import com.example.EventEase.entity.User;
import com.example.EventEase.repository.EventRepository;
import com.example.EventEase.repository.RegistrationRepository;
import com.example.EventEase.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class RegistrationService {

    private final RegistrationRepository registrationRepository;
    private final UserRepository userRepository;
    private final EventRepository eventRepository;

    public RegistrationService(RegistrationRepository registrationRepository,
                               UserRepository userRepository,
                               EventRepository eventRepository) {
        this.registrationRepository = registrationRepository;
        this.userRepository = userRepository;
        this.eventRepository = eventRepository;
    }

    public List<Registration> getAllRegistrations() {
        return registrationRepository.findAll();
    }

    public List<Registration> getRegistrationsByUserId(Long userId) {
        return registrationRepository.findByUserId(userId);
    }

    public Registration getRegistrationById(Long id) {
        return registrationRepository.findById(id).orElse(null);
    }

    @Transactional
    public Registration registerUserForEvent(Long userId, Long eventId) {
        // 1. Find User
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("User not found with ID: " + userId));

        // 2. Find Event
        Event event = eventRepository.findById(eventId)
                .orElseThrow(() -> new IllegalArgumentException("Event not found with ID: " + eventId));

        // 3. Check for Duplicate Registration
        if (registrationRepository.existsByUserAndEvent(user, event)) {
            throw new IllegalArgumentException("User '" + user.getName() + "' is already registered for '" + event.getTitle() + "'.");
        }

        // 4. Check Seat Availability (Capacity)
        long currentRegistrations = registrationRepository.countByEvent(event);
        if (currentRegistrations >= event.getCapacity()) {
            throw new IllegalStateException("Registration closed. The event '" + event.getTitle() + "' is completely full!");
        }

        // 5. Create and save registration
        Registration registration = new Registration(user, event, LocalDateTime.now());
        return registrationRepository.save(registration);
    }

    public void deleteRegistration(Long id) {
        registrationRepository.deleteById(id);
    }

    public long getRegistrationCountForEvent(Long eventId) {
        Event event = eventRepository.findById(eventId).orElse(null);
        if (event == null) return 0;
        return registrationRepository.countByEvent(event);
    }
}
