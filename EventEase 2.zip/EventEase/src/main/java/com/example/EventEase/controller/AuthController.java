package com.example.EventEase.controller;

import com.example.EventEase.entity.User;
import com.example.EventEase.service.UserService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class AuthController {

    private final UserService userService;

    public AuthController(UserService userService) {
        this.userService = userService;
    }

    // 1. Show Login Page
    @GetMapping("/login")
    public String showLoginForm(@RequestParam(value = "redirect", required = false) String redirectUrl,
                                HttpSession session,
                                Model model) {
        // If already logged in, redirect to home
        if (session.getAttribute("currentUser") != null) {
            return "redirect:/";
        }
        model.addAttribute("redirectUrl", redirectUrl);
        return "auth/login";
    }

    // 2. Process Login Submission
    @PostMapping("/login")
    public String processLogin(@RequestParam("email") String email,
                               @RequestParam("password") String password,
                               @RequestParam(value = "redirectUrl", required = false) String redirectUrl,
                               HttpSession session,
                               RedirectAttributes redirectAttributes) {
        User user = userService.authenticate(email, password);
        if (user == null) {
            redirectAttributes.addFlashAttribute("errorMessage", "Invalid email or password. Please try again.");
            if (redirectUrl != null && !redirectUrl.isEmpty()) {
                return "redirect:/login?redirect=" + redirectUrl;
            }
            return "redirect:/login";
        }

        // Store user in session
        session.setAttribute("currentUser", user);
        redirectAttributes.addFlashAttribute("successMessage", "Welcome back, " + user.getName() + "!");

        // Redirect to intended page or dashboard
        if (redirectUrl != null && !redirectUrl.trim().isEmpty() && !redirectUrl.equals("/login")) {
            return "redirect:" + redirectUrl;
        }

        if (user.isAdmin()) {
            return "redirect:/events/admin";
        }
        return "redirect:/events";
    }

    // 3. Show Sign-Up / Register Page
    @GetMapping("/register")
    public String showRegisterForm(HttpSession session, Model model) {
        if (session.getAttribute("currentUser") != null) {
            return "redirect:/";
        }
        model.addAttribute("user", new User());
        return "auth/register";
    }

    // 4. Process Sign-Up Submission
    @PostMapping("/register")
    public String processRegister(@Valid @ModelAttribute("user") User user,
                                  BindingResult result,
                                  HttpSession session,
                                  RedirectAttributes redirectAttributes) {
        if (result.hasErrors()) {
            return "auth/register";
        }

        if (userService.existsByEmail(user.getEmail())) {
            result.rejectValue("email", "error.user", "An account with this email address already exists.");
            return "auth/register";
        }

        user.setRole("USER");
        User savedUser = userService.saveUser(user);

        // Auto-login after sign-up
        session.setAttribute("currentUser", savedUser);
        redirectAttributes.addFlashAttribute("successMessage", "Account created successfully! Welcome, " + savedUser.getName() + ".");
        return "redirect:/events";
    }

    // 5. Logout
    @GetMapping("/logout")
    public String logout(HttpSession session, RedirectAttributes redirectAttributes) {
        session.invalidate();
        redirectAttributes.addFlashAttribute("successMessage", "You have been logged out successfully.");
        return "redirect:/login";
    }
}
